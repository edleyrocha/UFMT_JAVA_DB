package br.ufmt.ic.posbd.escolar.dao.jpa;

import br.ufmt.ic.posbd.escolar.dao.SalaTurmaDAO;
import br.ufmt.ic.posbd.escolarMysql.entidade.SalaTurma;

public class SalaTurmaDAOImpl extends DAOImpl<SalaTurma> implements SalaTurmaDAO{
    
}
