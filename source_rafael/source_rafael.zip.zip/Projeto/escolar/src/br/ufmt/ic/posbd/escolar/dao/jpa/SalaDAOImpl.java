package br.ufmt.ic.posbd.escolar.dao.jpa;

import br.ufmt.ic.posbd.escolar.dao.SalaDAO;
import br.ufmt.ic.posbd.escolarMysql.entidade.Sala;

public class SalaDAOImpl extends DAOImpl<Sala> implements SalaDAO{
    
}
