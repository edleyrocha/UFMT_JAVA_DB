package br.ufmt.ic.posbd.escolar.dao.jpa;

import br.ufmt.ic.posbd.escolar.dao.CursoDAO;
import br.ufmt.ic.posbd.escolarPostgresql.entidade.Curso;

public class CursoDAOImpl extends DAOImpl<Curso> implements CursoDAO{
    
}
