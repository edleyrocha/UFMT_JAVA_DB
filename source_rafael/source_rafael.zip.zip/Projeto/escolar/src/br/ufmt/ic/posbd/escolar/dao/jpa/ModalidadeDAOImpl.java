package br.ufmt.ic.posbd.escolar.dao.jpa;

import br.ufmt.ic.posbd.escolar.dao.ModalidadeDAO;
import br.ufmt.ic.posbd.escolarMysql.entidade.Modalidade;

public class ModalidadeDAOImpl extends DAOImpl<Modalidade> implements ModalidadeDAO{
    
}
