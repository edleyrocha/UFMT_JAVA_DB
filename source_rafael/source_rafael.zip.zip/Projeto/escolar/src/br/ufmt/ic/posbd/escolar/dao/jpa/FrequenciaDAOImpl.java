package br.ufmt.ic.posbd.escolar.dao.jpa;

import br.ufmt.ic.posbd.escolar.dao.FrequenciaDAO;
import br.ufmt.ic.posbd.escolarPostgresql.entidade.Frequencia;

public class FrequenciaDAOImpl extends DAOImpl<Frequencia> implements FrequenciaDAO{
    
}
