package br.ufmt.ic.posbd.escolar.dao.jpa;

import br.ufmt.ic.posbd.escolar.dao.TurmaDAO;
import br.ufmt.ic.posbd.escolarMysql.entidade.Turma;

public class TurmaDAOImpl extends DAOImpl<Turma> implements TurmaDAO{
    
}
