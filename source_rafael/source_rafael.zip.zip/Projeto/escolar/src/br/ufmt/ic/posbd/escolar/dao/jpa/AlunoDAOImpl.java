package br.ufmt.ic.posbd.escolar.dao.jpa;

import br.ufmt.ic.posbd.escolar.dao.AlunoDAO;
import br.ufmt.ic.posbd.escolarPostgresql.entidade.Aluno;

public class AlunoDAOImpl extends DAOImpl<Aluno> implements AlunoDAO{
    
}
