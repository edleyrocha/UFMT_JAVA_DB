package br.ufmt.ic.posbd.escolar.dao.jpa;

import br.ufmt.ic.posbd.escolar.dao.DisciplinaDAO;
import br.ufmt.ic.posbd.escolarPostgresql.entidade.Disciplina;

public class DisciplinaDAOImpl extends DAOImpl<Disciplina> implements DisciplinaDAO{
    
}
