package br.ufmt.ic.posbd.escolar.dao.jpa;

import br.ufmt.ic.posbd.escolar.dao.ProfessorDAO;
import br.ufmt.ic.posbd.escolarMysql.entidade.Professor;

public class ProfessorDAOImpl extends DAOImpl<Professor> implements ProfessorDAO{
    
}
