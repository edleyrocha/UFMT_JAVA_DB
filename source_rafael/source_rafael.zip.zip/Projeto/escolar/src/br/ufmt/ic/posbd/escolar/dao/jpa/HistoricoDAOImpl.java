package br.ufmt.ic.posbd.escolar.dao.jpa;

import br.ufmt.ic.posbd.escolar.dao.HistoricoDAO;
import br.ufmt.ic.posbd.escolarPostgresql.entidade.Historico;

public class HistoricoDAOImpl extends DAOImpl<Historico> implements HistoricoDAO{
    
}
