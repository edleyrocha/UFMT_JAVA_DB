package br.ufmt.ic.posbd.escolar.dao.jpa;

import br.ufmt.ic.posbd.escolar.dao.ResponsavelDAO;
import br.ufmt.ic.posbd.escolarMysql.entidade.Responsavel;

public class ResponsavelDAOImpl extends DAOImpl<Responsavel> implements ResponsavelDAO{
    
}
